public class Percentages {
    public static void main(String[] args) {
        double a = 2.0;
        double b = 4.0;
        computePercent(a,b);
    }
    public static void computePercent(double c, double d) {
        System.out.println(c + " is " + c/d*100 + " percent of " + d);
    }
}
